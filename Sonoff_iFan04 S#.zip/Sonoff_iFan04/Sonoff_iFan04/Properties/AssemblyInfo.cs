﻿using System.Reflection;

[assembly: AssemblyTitle("Sonoff_iFan04")]
[assembly: AssemblyCompany("HP Inc.")]
[assembly: AssemblyProduct("Sonoff_iFan04")]
[assembly: AssemblyCopyright("Copyright © HP Inc. 2024")]
[assembly: AssemblyVersion("1.0.0.*")]

