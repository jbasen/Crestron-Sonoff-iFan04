﻿using System;
using System.Text;
using Crestron.SimplSharp;
using Crestron.SimplSharp.Net.Http;

namespace Sonoff_iFan04
{
	#region Enum
	enum Debug_Options
	{
		None,								//Don't do anything with debug information
		Console,							//Output debug information to the console
		Error_Log,							//Send debug information to the error log
		Both								//Send debug infomation to both the console and error log
	};
	#endregion

	public class iFan04
	{
		#region Declarations
		private string IP_Address;
		private Debug_Options Debug;
		#endregion


		//****************************************************************************************
		// 
		//  iFan04	-	Default Constructor
		// 
		//****************************************************************************************
		public iFan04()
		{
		}

		//****************************************************************************************
		// 
		//  Initialize	-	Initialization
		// 
		//****************************************************************************************
		public short Initialize(string IP_Address, short Debug)
		{
			#region Save Parameters
			this.IP_Address = IP_Address;
			#endregion

			Set_Debug_Message_Output(Debug);

			Debug_Message("Initialize", "SUCCESS");
			return 1;
		}

		//****************************************************************************************
		// 
		//  Send_Command	-	Send Http command
		// 
		//****************************************************************************************
		public short Send_Command(string Command_1, string Command_2, ref short Light, ref short Fan)
		{
			HttpClient client = null;
			string s;

			#region Create url
			//Create url
			string url = "http://" + IP_Address + "/cm?cmnd=" + Command_1 + "%20" + Command_2;
			Debug_Message("Send_Command", "URL: " + url);
			#endregion

			#region Send Command
			try
			{
				#region Make Request
				//Create http client
				client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Url.Parse(url);
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;

				//Get response
				response = client.Dispatch(request);
				#endregion

				#region Manage Response
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Sonoff_iFan04 - Send_Command - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					return 0;
				}
				else
				{
					Debug_Message("Send_Command", "response.ContentString: " + response.ContentString);
					s = Parse_Data_Substring(response.ContentString, "", "\"POWER1\":\"", "\"");
					s = s.ToUpper();
					if (s == "")
					{
						Light = (Int16) (-1);
					}
					else if (s == "ON")
					{
						Light = (Int16) 1;
					}
					else if (s == "OFF")
					{
						Light = (Int16) 0;
					}
					else
					{
						Light = (Int16) (-1);
					}

					s = Parse_Data_Substring(response.ContentString, "", "\"FanSpeed\":", "}");
					if (s != "")
					{
						Fan = Int16.Parse(s);
					}
					else
					{
						Fan = (Int16)(-1);
					}
				}
				#endregion
			}
			catch (Exception e)
			{
				string err = "Sonoff_iFan04 - Send_Command - Error sending command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return 0;
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion

			return 1;
		}

		//****************************************************************************************
		// 
		//  Poll	-	Send Http command to Poll for Status
		// 
		//****************************************************************************************
		public short Poll(ref short Light, ref short Fan)
		{
			HttpClient client = null;
			string s;


			#region Light State
			try
			{
				#region Create url
				//Create url
				string url = "http://" + IP_Address + "/cm?cmnd=Power";
				Debug_Message("Poll Light State", "URL: " + url);
				#endregion

				#region Make Request
				//Create http client
				client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Url.Parse(url);
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;

				//Get response
				response = client.Dispatch(request);
				#endregion

				#region Manage Response
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Sonoff_iFan04 - Poll - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					return 0;
				}
				else
				{
					Debug_Message("Poll", "response.ContentString: " + response.ContentString);
					s = Parse_Data_Substring(response.ContentString, "", "\"POWER1\":\"", "\"");
					s = s.ToUpper();
					if (s == "")
					{
						Light = (Int16)(-1);
					}
					else if (s == "ON")
					{
						Light = (Int16)1;
					}
					else if (s == "OFF")
					{
						Light = (Int16)0;
					}
					else
					{
						Light = (Int16)(-1);
					}
				}
				#endregion
			}
			catch (Exception e)
			{
				string err = "Sonoff_iFan04 - Poll - Error sending command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return 0;
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion

			#region Fan Speed
			try
			{
				#region Create url
				//Create url
				string url = "http://" + IP_Address + "/cm?cmnd=FanSpeed";
				Debug_Message("Poll Fan Speed", "URL: " + url);
				#endregion

				#region Make Request
				//Create http client
				client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Url.Parse(url);
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;

				//Get response
				response = client.Dispatch(request);
				#endregion

				#region Manage Response
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Sonoff_iFan04 - Poll - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					return 0;
				}
				else
				{
					Debug_Message("Poll", "response.ContentString: " + response.ContentString);
					s = Parse_Data_Substring(response.ContentString, "", "\"FanSpeed\":", "}");
					if (s != "")
					{
						Fan = Int16.Parse(s);
					}
					else
					{
						Fan = (Int16)(-1);
					}
				}
				#endregion
			}
			catch (Exception e)
			{
				string err = "Sonoff_iFan04 - Poll - Error sending command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return 0;
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion

			return 1;
		}

		//****************************************************************************************
		// 
		//  Parse_Data_Substring	-	Parse Data Element from Json
		// 
		//****************************************************************************************
		private string Parse_Data_Substring(string s, string section, string id, string ending_char)
		{
			int index1, index2, section_index;

			//if data element located within a specific section of json, go to that section
			if (section != "")
			{
				section_index = s.IndexOf(section, 0);
				if (section_index == -1)
				{
					//CrestronConsole.PrintLine("SmartSlydr-Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					//Crestron.SimplSharp.ErrorLog.Error("SmartSlydr-Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					return "";
				}
				else
				{
					section_index += section.Length;
				}
			}
			else
			{
				section_index = 0;
			}

			//get index to start of value
			index1 = s.IndexOf(id, section_index);
			if (index1 == -1)
			{
				//CrestronConsole.PrintLine("SmartSlydr-Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				//Crestron.SimplSharp.ErrorLog.Error("SmartSlydr-Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				return "";
			}
			else
			{
				index1 += id.Length;
			}

			//get index to end of value
			index2 = s.IndexOf(ending_char, (index1 + 1));
			if (index2 == -1)
			{
				CrestronConsole.PrintLine("SmartSlydr-Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				Crestron.SimplSharp.ErrorLog.Error("SmartSlydr-Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				return "";
			}

			//get value substring and pass it back
			return s.Substring(index1, index2 - index1);
		}

		//****************************************************************************************
		// 
		//  Set_Debug_Message_Output	-	Save whether debug messages will be output
		//									to console, error log, both, or not sent
		//									0 = None, 1 = Console, 2 = Error Log, 3 = Both
		// 
		//****************************************************************************************
		public void Set_Debug_Message_Output(short Debug)
		{
			//Save debug message setting as an enum
			switch (Debug)
			{
				case 0:
					this.Debug = Debug_Options.None;
					break;

				case 1:
					this.Debug = Debug_Options.Console;
					break;

				case 2:
					this.Debug = Debug_Options.Error_Log;
					break;

				case 3:
					this.Debug = Debug_Options.Both;
					break;
			}
		}

		//****************************************************************************************
		// 
		//  Debug_Message	-	Send Debug Message to Console or Error Log
		//						Depending on Selection
		// 
		//****************************************************************************************
		private void Debug_Message(string Name, string s)
		{
			const int characters_per_line = 250;
			int start_index = 0;
			int length = characters_per_line;

			//json responses are too large for Simpl Debugger to display on a single line
			//so, we break them up into chunks of 250 characters to be printed on 1 line
			while (start_index < s.Length)
			{
				if ((start_index + characters_per_line) > s.Length)
				{
					length = s.Length - start_index;
				}

				string sub = s.Substring(start_index, length);

				if ((Debug == Debug_Options.Console) || (Debug == Debug_Options.Both))
				{
					CrestronConsole.PrintLine("Sonoff_iFan04 - " + Name + " - " + sub);
				}

				if ((Debug == Debug_Options.Error_Log) || (Debug == Debug_Options.Both))
				{
					Crestron.SimplSharp.ErrorLog.Notice("Sonoff_iFan04 - " + Name + " - " + sub + "\n");
				}

				start_index += characters_per_line;
			}
		}
	}
}
